(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@tanstack+query-devtools@5.96.2/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/NXRPVNXJ.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/1fb7a_@tanstack_query-devtools_build_abc0f9a8._.js",
  "static/chunks/1fb7a_@tanstack_query-devtools_build_DevtoolsComponent_NXRPVNXJ_48811f44.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/@tanstack+query-devtools@5.96.2/node_modules/@tanstack/query-devtools/build/DevtoolsComponent/NXRPVNXJ.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/.pnpm/@tanstack+query-devtools@5.96.2/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/RXFVSJH2.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/1fb7a_@tanstack_query-devtools_build_caa521e8._.js",
  "static/chunks/1fb7a_@tanstack_query-devtools_build_DevtoolsPanelComponent_RXFVSJH2_48811f44.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/@tanstack+query-devtools@5.96.2/node_modules/@tanstack/query-devtools/build/DevtoolsPanelComponent/RXFVSJH2.js [app-client] (ecmascript)");
    });
});
}),
]);