(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1fb7a_@tanstack_query-devtools_build_abc0f9a8._.js"
],
    source: "dynamic"
});
