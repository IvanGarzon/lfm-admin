(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_5314c45c._.js",
  "static/chunks/6065d_next_dist_compiled_react-dom_955cdd4c._.js",
  "static/chunks/6065d_next_dist_compiled_react-server-dom-turbopack_8e89bec9._.js",
  "static/chunks/6065d_next_dist_compiled_next-devtools_index_4f407cfd.js",
  "static/chunks/6065d_next_dist_compiled_74cb3aca._.js",
  "static/chunks/6065d_next_dist_client_819d4345._.js",
  "static/chunks/6065d_next_dist_c35539a1._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
