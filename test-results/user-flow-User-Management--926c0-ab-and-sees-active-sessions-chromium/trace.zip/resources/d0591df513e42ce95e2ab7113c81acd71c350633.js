(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_features_users_components_e1941796._.js",
  "static/chunks/_262d79d8._.js",
  "static/chunks/275fa_@tanstack_table-core_build_lib_index_mjs_6f1bc5e2._.js",
  "static/chunks/50d1e_date-fns_c27cdfed._.js",
  "static/chunks/e5f61_@radix-ui_react-select_dist_index_mjs_859fd1ab._.js",
  "static/chunks/44636_react-day-picker_dist_esm_797c2380._.js",
  "static/chunks/node_modules__pnpm_e8c629e8._.js"
],
    source: "dynamic"
});
