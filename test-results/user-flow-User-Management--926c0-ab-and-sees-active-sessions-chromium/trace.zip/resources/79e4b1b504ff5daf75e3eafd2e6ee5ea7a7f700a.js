(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_83e17474._.js",
  "static/chunks/4cecd_@radix-ui_react-icons_dist_react-icons_esm_94521580.js",
  "static/chunks/node_modules__pnpm_6f425bf3._.js"
],
    source: "dynamic"
});
