(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_features_users_components_f50fc9c6._.js",
  "static/chunks/src_components_2ad59aef._.js",
  "static/chunks/src_features_7025f91f._.js",
  "static/chunks/src_actions_b67f15a2._.js",
  "static/chunks/src_3a51d0f1._.js",
  "static/chunks/prisma_zod_schemas_enums_a4cac282._.js",
  "static/chunks/275fa_@tanstack_table-core_build_lib_index_mjs_6f1bc5e2._.js",
  "static/chunks/50d1e_date-fns_8f150ca0._.js",
  "static/chunks/e5f61_@radix-ui_react-select_dist_index_mjs_859fd1ab._.js",
  "static/chunks/44636_react-day-picker_dist_esm_797c2380._.js",
  "static/chunks/a4cbd_react-hook-form_dist_index_esm_mjs_fc0cb332._.js",
  "static/chunks/3f89a_react-icons_fa_index_mjs_1e4a4e58._.js",
  "static/chunks/3f89a_react-icons_hi2_index_mjs_1439b1a0._.js",
  "static/chunks/3f89a_react-icons_md_index_mjs_2967e371._.js",
  "static/chunks/3f89a_react-icons_lib_dd886cb3._.js",
  "static/chunks/node_modules__pnpm_b66aaa71._.js"
],
    source: "dynamic"
});
