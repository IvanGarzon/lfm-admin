(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/features/users/components/user-drawer.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_features_users_components_user-drawer_tsx_a31df3c8._.js",
  "static/chunks/src_features_users_components_user-drawer_tsx_3c3710a7._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/users/components/user-drawer.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/features/users/components/user-invite-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_features_users_components_user-invite-modal_tsx_b9f54d26._.js",
  "static/chunks/src_features_users_components_user-invite-modal_tsx_3c3710a7._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/users/components/user-invite-modal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);