(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/features/users/components/user-drawer.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_e19576b7._.js",
  "static/chunks/a4cbd_react-hook-form_dist_index_esm_mjs_fc0cb332._.js",
  "static/chunks/3f89a_react-icons_fa_index_mjs_1e4a4e58._.js",
  "static/chunks/3f89a_react-icons_hi2_index_mjs_1439b1a0._.js",
  "static/chunks/3f89a_react-icons_md_index_mjs_2967e371._.js",
  "static/chunks/3f89a_react-icons_lib_dd886cb3._.js",
  "static/chunks/node_modules__pnpm_7508b522._.js",
  "static/chunks/src_features_users_components_user-drawer_tsx_c33a08c3._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/users/components/user-drawer.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
"[project]/src/features/users/components/user-invite-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules__pnpm_8d82cc7c._.js",
  "static/chunks/src_3eb56ede._.js",
  "static/chunks/src_features_users_components_user-invite-modal_tsx_c33a08c3._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/features/users/components/user-invite-modal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);