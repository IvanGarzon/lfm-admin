(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__57ebe6a2._.css",
  "static/chunks/1fb7a_@tanstack_query-devtools_build_84f8f66c._.js",
  "static/chunks/35b79_tailwind-merge_dist_bundle-mjs_mjs_8fe727c0._.js",
  "static/chunks/a8d7e_zod_v4_f9812d86._.js",
  "static/chunks/1fb7a_@tanstack_query-devtools_build_ccbd8244._.js",
  "static/chunks/node_modules__pnpm_df22d638._.js",
  "static/chunks/_93f0edb7._.js"
],
    source: "dynamic"
});
